import javax.swing.*;

public class CanvasFrame extends JFrame 
{
    public CanvasFrame() {
        this.setTitle("Snake Game");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.add(new CanvasPanel());
        this.pack();
        this.setVisible(true);
        this.setLocationRelativeTo(null);
    }
}