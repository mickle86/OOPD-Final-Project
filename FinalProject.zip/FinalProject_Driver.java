/**
* @author Andrew Mickley and Mackenzie Carey
* @version 4-18-2025
*/
public class FinalProject_Driver
{
    public static void main(String[] args)
    {   
        P1();
    }
    public static void P1()
    {
        new CanvasFrame();
    }
}