/**
* @author Andrew Mickley and Mackenzie Carey
* @version 4-18-2025
*/

import java.awt.Graphics;

public class Rectangle2D extends Shape2D 
{
    private int width, height;

    public Rectangle2D(int fillColorIndex, int xPos, int yPos, int width, int height) 
    {
        super(fillColorIndex, xPos, yPos);
        this.width = width;
        this.height = height;
    }

    @Override
    public void Draw(Graphics g) 
    {
        if (fill) {
            g.setColor(fillColor);
            g.fillRect(xPos, yPos, width, height);
        }
        if (outline) {
            g.setColor(outlineColor);
            g.drawRect(xPos, yPos, width, height);
        }
    }
}
