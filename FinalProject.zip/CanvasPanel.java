/**
* @author Andrew Mickley and Mackenzie Carey
* @version 4-18-2025
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class CanvasPanel extends JPanel implements ActionListener 
{
    private static final int GRID_SIZE = 20;
    private static final int NUM_ROWS = 20;
    private static final int NUM_COLS = 20;
    private static final int TILE_SIZE = 30;
    private static final int DELAY = 100;
    private int score = 0;

    private final LinkedList<Point> snake;
    private Point apple;
    private char direction;
    private boolean running;
    private javax.swing.Timer timer;
    private Random random;

    public CanvasPanel() 
    {
        this.snake = new LinkedList<>();
        this.direction = 'R';
        this.running = false;
        this.random = new Random();
        this.setPreferredSize(new Dimension(NUM_COLS * TILE_SIZE, NUM_ROWS * TILE_SIZE));
        this.setBackground(Color.GRAY);
        this.setFocusable(true);
        this.addKeyListener(new KeyAdapter() 
        {
            @Override
            public void keyPressed(KeyEvent e) 
            {
                switch (e.getKeyCode()) 
                {
                    case KeyEvent.VK_LEFT:
                        if (direction != 'R') direction = 'L';
                        break;
                    case KeyEvent.VK_RIGHT:
                        if (direction != 'L') direction = 'R';
                        break;
                    case KeyEvent.VK_UP:
                        if (direction != 'D') direction = 'U';
                        break;
                    case KeyEvent.VK_DOWN:
                        if (direction != 'U') direction = 'D';
                        break;
                }
            }
        });
        startGame();
    }

    private void startGame() 
    {
        score = 0;
        snake.clear();
        snake.add(new Point(NUM_COLS / 2, NUM_ROWS / 2));
        spawnApple();
        running = true;
        timer = new javax.swing.Timer(DELAY, this);
        timer.start();
    }

    private void spawnApple() 
    {
        int x = random.nextInt(NUM_COLS);
        int y = random.nextInt(NUM_ROWS);
        apple = new Point(x, y);
    }

    private void move() {
        Point head = snake.getFirst();
        Point newHead = null;
        switch (direction) 
        {
            case 'L': newHead = new Point(head.x - 1, head.y); break;
            case 'R': newHead = new Point(head.x + 1, head.y); break;
            case 'U': newHead = new Point(head.x, head.y - 1); break;
            case 'D': newHead = new Point(head.x, head.y + 1); break;
        }

        if (newHead.equals(apple)) 
        {
            playSound("apple-munch-40169.wav");
            snake.addFirst(newHead);
            spawnApple();
            score += 1;
        } 
        else 
        {
            snake.addFirst(newHead);
            snake.removeLast();
        }
    }

    private void checkCollisions() 
    {
        Point head = snake.getFirst();
        if (head.x < 0 || head.x >= NUM_COLS || head.y < 0 || head.y >= NUM_ROWS) 
        {
            running = false;
        }
        for (int i = 1; i < snake.size(); i++) 
        {
            if (head.equals(snake.get(i))) 
            {
                running = false;
            }
        }
        if (!running) 
        {
            playSound("videogame-death-sound-43894.wav");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        if (running) 
        {
            move();
            checkCollisions();
        }
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) 
    {
        super.paintComponent(g);
        drawGrid(g);
        drawSnake(g);
        drawApple(g);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 18));
        g.drawString("Score: " + score, 10, 20);
        if (!running) 
        {
            drawGameOver(g);
        }
    }

    private void drawGrid(Graphics g) 
    {
        g.setColor(Color.BLACK); 
        for (int i = 0; i <= NUM_COLS; i++) 
        { 
            g.drawLine(i * TILE_SIZE, 0, i * TILE_SIZE, NUM_ROWS * TILE_SIZE); 
        } 
        for (int i = 0; i <= NUM_ROWS; i++) 
        { 
            g.drawLine(0, i * TILE_SIZE, NUM_COLS * TILE_SIZE, i * TILE_SIZE); 
        } 
        for (int i = 0; i < NUM_ROWS; i++) 
        { 
            for (int j = 0; j < NUM_COLS; j++) 
            { 
                if ((i + j) % 2 == 0) 
                { 
                    g.setColor(Color.LIGHT_GRAY); 
                } 
                else 
                { 
                    g.setColor(Color.DARK_GRAY); 
                } 
                g.fillRect(j * TILE_SIZE, i * TILE_SIZE, TILE_SIZE, TILE_SIZE); } 
            } 
        Graphics2D g2 = (Graphics2D) g; 
        g2.setColor(Color.BLACK); 
        g2.setStroke(new BasicStroke(2.5f)); // Thicker stroke 
        g2.drawRect(0, 0, NUM_COLS * TILE_SIZE, NUM_ROWS * TILE_SIZE);
    }

    private void drawSnake(Graphics g) 
    {
        for (Point p : snake) 
        {
            g.setColor(Color.GREEN);
            g.fillRect(p.x * TILE_SIZE, p.y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
            g.setColor(Color.BLACK);
            g.drawRect(p.x * TILE_SIZE, p.y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
        }
    }

    private void drawApple(Graphics g) 
    {
        g.setColor(Color.RED);
        g.fillRect(apple.x * TILE_SIZE, apple.y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
        g.setColor(Color.BLACK);
        g.drawRect(apple.x * TILE_SIZE, apple.y * TILE_SIZE, TILE_SIZE, TILE_SIZE);
    }

    private void drawGameOver(Graphics g) 
    {
        playSound("Game+Over+01+(Voiced).wav");
        String message = "Game Over!";
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 30));
        FontMetrics metrics = g.getFontMetrics();
        int x = (getWidth() - metrics.stringWidth(message)) / 2;
        int y = getHeight() / 2;
        g.drawString(message, x, y);

        timer.stop(); // Stop the game timer before showing the dialog

        int response = JOptionPane.showOptionDialog(
            this,
            "Game Over! Your score was: " + score + " Would you like to Play Again or Quit?",
            "Game Over",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            new String[] { "Play Again", "Quit" },
            "Play Again"
        );

        if (response == JOptionPane.YES_OPTION) 
        {
            startGame(); // restart the game
        } 
        else 
        {
            System.exit(0); // quit the game
        }
    }
    
    private void playSound(String path) 
    {
        SoundPlayer.play(path);
    }
}
