/**
* @author Andrew Mickley and Mackenzie Carey
* @version 4-18-2025
*/

import java.awt.Graphics;
import java.awt.Color;

public abstract class Shape2D 
{
    public static final int RED = 0;
    public static final int GREEN = 1;
    public static final int BLUE = 2;
    public static final int BLACK = 3;
    public static final int GREY = 4;
    public static final int WHITE = 5;
    public static final int YELLOW = 6;
    public static final int CYAN = 7;
    public static final int MAGENTA = 8;
    public static final int BROWN = 9;
    
    public static final Color[] COLORS = {
        new Color(255, 0, 0),   // Red
        new Color(0, 255, 0),   // Green
        new Color(0, 0, 255),   // Blue
        new Color(0, 0, 0),     // Black
        new Color(128, 128, 128), // Grey
        new Color(255, 255, 255), // White
        new Color(255, 255, 0),   // Yellow
        new Color(0, 255, 255),   // Cyan
        new Color(255, 0, 255),   // Magenta
        new Color(165, 42, 42)    // Brown
    };
    
    protected int xPos, yPos;
    protected int xVel = 0, yVel = 0;
    protected Color fillColor;
    protected int fillColorIndex;
    protected Color outlineColor; 
    protected int outlineColorIndex;
    protected boolean fill = true; 
    protected boolean outline = false;
    protected double sX = 1.0, sY = 1.0; 
    protected double rotAngleZ = 0.0;   

    public Shape2D(int fillColorIndex, int xPos, int yPos) 
    {
        this.fillColorIndex = fillColorIndex;
        this.fillColor = COLORS[fillColorIndex];
        this.xPos = xPos;
        this.yPos = yPos;
        this.outlineColorIndex = 3;
        this.outlineColor = COLORS[outlineColorIndex];
        this.fill = true;
        this.outline = false;
    }
    
    public abstract void Draw(Graphics g);

    public void setVelocity(int xVel, int yVel) 
    {
        this.xVel = xVel;
        this.yVel = yVel;
    }

    public void updatePosition() 
    {
        this.xPos += xVel;
        this.yPos += yVel;
    }
    
    public void setOutline(boolean outline, int outlineColorIndex) 
    {
        this.outline = outline;
        this.outlineColorIndex = outlineColorIndex;
        this.outlineColor = COLORS[outlineColorIndex];
    }
    
    public void setOutlineColor(int outlineColorIndex) 
    {
        this.outlineColorIndex = outlineColorIndex;
        this.outlineColor = COLORS[outlineColorIndex];
    }
    
    public void Scale(double sx, double sy) 
    {
        this.sX = sx;
        this.sY = sy;
    }

    public void Rotate(double angleZ) 
    {
        this.rotAngleZ = angleZ;
    }

    public void Move(int dx, int dy) 
    {
        this.xPos += dx;
        this.yPos += dy;
    }

    public void SetPos(int x, int y) 
    {
        this.xPos = x;
        this.yPos = y;
    }
    
    public int GetX() 
    { 
        return xPos; 
    }
    
    public int GetY() 
    { 
        return yPos; 
    }
    
    public void SetSpeed(int xVel, int yVel) 
    {
    }
    
    public void Animate() 
    {
    }
}
