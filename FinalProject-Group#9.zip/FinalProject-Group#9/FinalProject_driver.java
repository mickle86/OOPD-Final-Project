
/**
 * The driver for the snake game 
 *
 * @author (Andrew Mickley)
 * @version (4/24/25)
 */
public class FinalProject_driver
{
  public static void main()
{
P1();
}
public static void P1()
{
    new CanvasPanel_FP();
}
}
