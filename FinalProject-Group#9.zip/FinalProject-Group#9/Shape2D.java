
/**
 * A abstract class made for a 2d shape object 
 *
 * @author (Andrew Mickley)
 * @version (4/10/25)
 */
import java.awt.*;
import java.awt.geom.*;

public abstract class Shape2D {
    // Color constants
    public static final int RED = 0;
    public static final int GREEN = 1;
    public static final int BLUE = 2;
    public static final int BLACK = 3;
    public static final int GREY = 4;
    public static final int WHITE = 5;
    public static final int YELLOW = 6;
    public static final int CYAN = 7;
    public static final int MAGENTA = 8;
    public static final int BROWN = 9;

    // Shared fields
    protected int xPos, yPos;
    protected int xVel = 0, yVel = 0;
    protected Color fillColor, outlineColor;
    protected int fillColorIndex, outlineColorIndex;
    protected boolean fill = true, outline = true;

    // Constructor
    public Shape2D(int colorIndex, int x, int y) {
        this.fillColorIndex = colorIndex;
        this.fillColor = getColorFromIndex(colorIndex);
        this.outlineColor = Color.BLACK;
        this.outlineColorIndex = BLACK;
        this.xPos = x;
        this.yPos = y;
    }

    // Abstract draw method to be implemented by all shapes
    public abstract void Draw(Graphics g);

    // Utility: convert index to color
    protected Color getColorFromIndex(int index) {
        switch (index) {
            case RED: return Color.RED;
            case GREEN: return Color.GREEN;
            case BLUE: return Color.BLUE;
            case BLACK: return Color.BLACK;
            case GREY: return Color.GRAY;
            case WHITE: return Color.WHITE;
            case YELLOW: return Color.YELLOW;
            case CYAN: return Color.CYAN;
            case MAGENTA: return Color.MAGENTA;
            case BROWN: return new Color(139, 69, 19);
            default: return Color.BLACK;
        }
    }

    // Move method for animation
    public void move() {
        xPos += xVel;
        yPos += yVel;
    }

    // NEW: Animate method (alias for move)
    public void Animate() {
        move();
    }

    // NEW: Set outline flag
    public void SetOutline(boolean outline) {
        this.outline = outline;
    }

    // NEW: Set outline color
    public void SetOutlineColor(Color c) {
        this.outlineColor = c;
    }

    // Compatibility methods for CanvasPanel_Le11
    public void Move(int dx, int dy) {
        this.xPos += dx;
        this.yPos += dy;
    }

    public void SetPos(int x, int y) {
        this.xPos = x;
        this.yPos = y;
    }

    public int GetX() {
        return this.xPos;
    }

    public int GetY() {
        return this.yPos;
    }

    public void SetSpeed(int dx, int dy) {
        this.xVel = dx;
        this.yVel = dy;
    }

    // Getters and Setters
    public int getXPos() {
        return xPos;
    }

    public void setXPos(int xPos) {
        this.xPos = xPos;
    }

    public int getYPos() {
        return yPos;
    }

    public void setYPos(int yPos) {
        this.yPos = yPos;
    }

    public int getXVel() {
        return xVel;
    }

    public void setXVel(int xVel) {
        this.xVel = xVel;
    }

    public int getYVel() {
        return yVel;
    }

    public void setYVel(int yVel) {
        this.yVel = yVel;
    }

    public Color getFillColor() {
        return fillColor;
    }

    public void setFillColor(Color fillColor) {
        this.fillColor = fillColor;
    }

    public int getFillColorIndex() {
        return fillColorIndex;
    }

    public void setFillColorIndex(int fillColorIndex) {
        this.fillColorIndex = fillColorIndex;
        this.fillColor = getColorFromIndex(fillColorIndex);
    }

    public Color getOutlineColor() {
        return outlineColor;
    }

    public void setOutlineColor(Color outlineColor) {
        this.outlineColor = outlineColor;
    }

    public int getOutlineColorIndex() {
        return outlineColorIndex;
    }

    public void SetOutlineColor(int colorIndex) {
       this.outlineColorIndex = colorIndex;
      this.outlineColor = getColorFromIndex(colorIndex);
    }


    public boolean isFill() {
        return fill;
    }

    public void setFill(boolean fill) {
        this.fill = fill;
    }

    public boolean isOutline() {
        return outline;
    }

    public void setOutline(boolean outline) {
        this.outline = outline;
    }
}
