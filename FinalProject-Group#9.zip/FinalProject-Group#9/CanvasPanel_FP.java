
/**
 * The cCanvas Panel class for the snake game
 *
 * @author (Andrew Mickley)
 * @version (4/24/25)
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
// For Sprites
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
public class CanvasPanel_FP
{
   
}
