
/**
 * A class for a rectangle 
 *
 * @author (Andrew Mickley)
 * @version (4/14/25)
 */
import java.awt.*;

public class Rectangle2D extends Shape2D {
    private int width, height;

    public Rectangle2D(int colorIndex, int x, int y, int width, int height) {
        super(colorIndex, x, y);
        this.width = width;
        this.height = height;
    }

    @Override
    public void Draw(Graphics g) {
        if (isFill()) {
            g.setColor(getFillColor());
            g.fillRect(getXPos(), getYPos(), width, height);
        }
        if (isOutline()) {
            g.setColor(getOutlineColor());
            g.drawRect(getXPos(), getYPos(), width, height);
        }
    }

    public void Move(int dx, int dy) {
        setXPos(getXPos() + dx);
        setYPos(getYPos() + dy);
    }
}